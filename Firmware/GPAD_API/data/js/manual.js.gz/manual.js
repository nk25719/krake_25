KrakeUI.mountLayout('User Manual');
